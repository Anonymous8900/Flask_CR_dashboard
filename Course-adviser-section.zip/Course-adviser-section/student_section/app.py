# from flask import Flask, render_template, request, redirect, url_for, session, jsonify
# from flask_mysqldb import MySQL
# import MySQLdb.cursors
# from datetime import date
# import re
# import os
# import sys
#
# app = Flask(__name__)
#
# app.secret_key = 'abcd21234455'
# app.config['MYSQL_HOST'] = 'localhost'
# app.config['MYSQL_USER'] = 'root'
# app.config['MYSQL_PASSWORD'] = 'AtestDB@24'
# app.config['MYSQL_DB'] = 'python_sms1'
#
# mysql = MySQL(app)
#
#
# @app.route('/')
# @app.route('/login', methods=['GET', 'POST'])
# def login():
#     mesage = ''
#     if request.method == 'POST' and 'email' in request.form and 'password' in request.form:
#         email = request.form['email']
#         password = request.form['password']
#         cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
#         cursor.execute('SELECT * FROM sms_user WHERE status="active" AND email = % s AND password = % s',
#                        (email, password,))
#         user = cursor.fetchone()
#         if user:
#             session['loggedin'] = True
#             session['userid'] = user['id']
#             session['name'] = user['first_name']
#             session['email'] = user['email']
#             session['role'] = user['type']
#             mesage = 'Logged in successfully !'
#             return redirect(url_for('dashboard'))
#         else:
#             mesage = 'Please enter correct email / password !'
#     return render_template('login.html', mesage=mesage)
#
#
# @app.route('/logout')
# def logout():
#     session.pop('loggedin', None)
#     session.pop('userid', None)
#     session.pop('email', None)
#     session.pop('name', None)
#     session.pop('role', None)
#     return redirect(url_for('login'))
#
#
# @app.route("/result", methods=['GET', 'POST'])
# def dashboard():
#     if 'loggedin' in session:
#         return render_template("result.html")
#     return redirect(url_for('login'))
#
#
#
# if __name__ == "__main__":
#     app.run()
#     os.execv(__file__, sys.argv)

import csv
from flask import Flask, request, session, redirect, url_for, render_template

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Change this to a random secret key

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        token = request.form['password']
        with open('data.csv', 'r') as file:
            csv_file = csv.reader(file)
            for row in csv_file:
                if row[0] == token:
                    session['logged_in'] = True
                    session['courses'] = row[1:]  # Store course information in session
                    return redirect(url_for('result'))
        return "Login Failed", 401
    return render_template('login.html')  # Serve the login page

@app.route('/result')
def result():
    if not session.get('logged_in'):
        return redirect(url_for('login'))  # Redirect back to login if not logged in
    return render_template('result.html', courses=session['courses'])  # Pass courses to the template

if __name__ == '__main__':
    app.run(debug=True)

